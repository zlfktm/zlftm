def main():
    print("Hello from django-todo-list-app!")


if __name__ == "__main__":
    main()
